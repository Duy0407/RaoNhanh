<?php 

?>
<html>
    <head>
        <title>Transaction</title>
        <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
        <meta name="description" content="Thanh to�n tr?c tuy?n" />
        <!-- css -->
        <link rel="stylesheet" href="css/bootstrap.css" /> 
        <link rel="stylesheet" href="css/bootstrap-responsive.css" /> 
        <link rel="stylesheet" href="css/bootstrap-theme.css" /> 
        
        <!-- Script -->
        <script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
        <script src="js/jquery.form.js"></script> 
        <script src="js/bootstrap.min.js"></script> 
        
       
    </head>
    <body>
        <div style="margin: 0 auto; width: 500px;">
            
            <h3 style="margin-bottom: 20px;"><span class="label label-success">H&#7879; th&#7889;ng n&#7841;p th&#7867; c&#224;o tr&#7921;c tuy&#7871;n PAYCARD365</span></h3>
            <center><?=$status?></center>
        </div>
    </body>
</html>